#pragma once

const char CGFVersion[]= "v2.2.1";
const char CGFId[]= "$Id$";

